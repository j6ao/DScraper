import { Client, GatewayIntentBits, Partials } from "discord.js";
import handler from "./handler.js";
import express from "express";
import cors from "cors";
import "dotenv/config";


const client = new Client({
    intents: [GatewayIntentBits.GuildMembers, GatewayIntentBits.Guilds],
    partials: [Partials.User, Partials.GuildMember],
});
const app = express()

app.use(cors({
    origin: "*",
    methods: ["GET"],
}));
handler(app);

app.listen(80, () => {
    console.log("[API]", "Connected.")
    client.login(process.env.BOT_TOKEN).then(() => {
        console.log("[BOT]",`Connected ${client.user.tag}` )
    });
});

export default client;

process.on("unhandledRejection", (reason, promise) => {
    console.log(reason, promise);
  });
process.on("uncaughtException", (error, origin) => {
    console.log(error, origin);
  });
process.on("uncaughtExceptionMonitor", (error, origin) => {
    console.log(error, origin);
  });