import { EmbedBuilder, WebhookClient } from "discord.js";
import * as fs from "fs";
import axios from "axios";
import moment from "moment";
moment.locale('pt-br')

var config = require('./config.json')
const api = config.api

const badges__: { [key: string]: string } = {
    'HypeSquadOnlineHouse1': '<:hbravery:1095301030113185812>',
    'HypeSquadOnlineHouse2': '<:hbrilliance:1095300908260278452>',
    'HypeSquadOnlineHouse3': '<:hbalance:1095300641502543902>',
    'PremiumEarlySupporter': '<:early:1095300806435164162>',
    'VerifiedDeveloper': '<:dev:1095300710331064340>',
    'ActiveDeveloper': '<:active:1095300613371347034>',
    'Hypesquad': '<:hevents:1095300862156480523>',
    'Nitro': '<:nitro:1095299114691993620>',
    'Staff': '<:staff:1095300685395939408>',
    'CertifiedModerator': '<:mod:1095300834448920626>',
    'BugHunterLevel1': '<:bughunter:1095300741675090011>',
    'BugHunterLevel2': '<:gbughunter:1095301069929725992>',
    'Partner': '<:partner:1095300783139979284>',
    'BoostLevel1': '<:b1:1095297294762516551>',
    'BoostLevel2': '<:b2:1095296835117137980>',
    'BoostLevel3': '<:b3:1095297935543128094>',
    'BoostLevel4': '<:b4:1095297273103138876>',
    'BoostLevel5': '<:b5:1095297932254793758>',
    'BoostLevel6': '<:b6:1095297930883256350>',
    'BoostLevel7': '<:b7:1095299092441223228>',
    'BoostLevel8': '<:b8:1095297933882183732>',
    'BoostLevel9': '<:b9:1095298787574034462>',
    'legacyUsername': '<:lgc:1120563735212343366>',
};
const badges_validas: { [key: string]: string } = {
    'BoostLevel3': '<:b3:1095297935543128094>',
    'BoostLevel4': '<:b4:1095297273103138876>',
    'BoostLevel5': '<:b5:1095297932254793758>',
    'BoostLevel6': '<:b6:1095297930883256350>',
    'BoostLevel7': '<:b7:1095299092441223228>',
    'BoostLevel8': '<:b8:1095297933882183732>',
    'BoostLevel9': '<:b9:1095298787574034462>',
    'PremiumEarlySupporter': '<:early:1095300806435164162>',
    'BugHunterLevel1': '<:bughunter:1095300741675090011>',
    'BugHunterLevel2': '<:gbughunter:1095301069929725992>',
    'Hypesquad': '<:hevents:1095300862156480523>',
    'VerifiedDeveloper': '<:dev:1095300710331064340>',
    'Partner': '<:partner:1095300783139979284>',
    'CertifiedModerator': '<:mod:1095300834448920626>',
}

function ver_ids(filePath: string): string[] {
    try {
      const conteudo: string = fs.readFileSync(filePath, 'utf-8');
      const ids: string[] = conteudo.trim().split('\n');
      return ids;
    } catch (e) {
      console.log(e);
      return [];
    }
} 
async function enviar_usuario(embed: EmbedBuilder): Promise<void> {
    try {
        const webhook = new WebhookClient({
            url: config.webhook
        })

        await webhook.send({
            content: ":people_hugging: Novo usuário encontrado",
            embeds: [embed]
        });
        
        console.log("[DS] Usuário Scrapado")
    } catch(e) {
        console.log(e)
    }
}

async function DScraper(): Promise<void> {
    var ids_:string = 'ids.txt';
    var ids: string[] = ver_ids(ids_);

    for (let i = 0; i < ids.length; i++) {
        var id: string = ids[i];
        var api_url: string = api + id

        try {
            const request = await axios.get(api_url)
            const user_data: any = request.data
            
            if(user_data.profile.badgesArray) {
                const badges_array: string = user_data.profile.badgesArray
                .filter((badge: string) => badges_validas[badge])
                .map((badge: string) => badges_validas[badge])
                .join('')

                if (badges_array.length > 0) {
                    const user_badges: string = user_data.profile.badgesArray
                    .map((badge: string) => badges__[badge])
                    .join('')

                    var embed: EmbedBuilder = new EmbedBuilder()
                    .setColor("#2b2e31")
                    if(user_data.user.globalName) {
                        embed.setAuthor({
                            name: `${user_data.user.globalName}`,
                            iconURL: 'https://cdn.discordapp.com/attachments/994068163211825275/1173424808646672444/a_662424ea5835182d84ebcab18731e6d0.gif?ex=6563e803&is=65517303&hm=dacf10f72720618608aeedf8f1ed605c0eb562499a146f69a90ad420e936ed08&'
                        })
                } else {
                    embed.setAuthor({
                        name: `${user_data.user.username}`,
                        iconURL: 'https://cdn.discordapp.com/attachments/994068163211825275/1173424808646672444/a_662424ea5835182d84ebcab18731e6d0.gif?ex=6563e803&is=65517303&hm=dacf10f72720618608aeedf8f1ed605c0eb562499a146f69a90ad420e936ed08&'
                    })
                }
                    embed.setThumbnail(user_data.profile.avatarUrl)
                    .setTimestamp()
                    .setImage(user_data.profile.bannerUrl)
                    if (user_data.user.discriminator !== "0") {
                        embed.setTitle(`**Badges**: ${user_badges}`)
                        embed.setFields(
                            {
                                name: "👥 **Usuário**:",
                                value: `${user_data.user.tag}`,
                                inline: true,
                            }, 
                            {
                                name: "🆔 **ID**:",
                                value: `\`${user_data.user.id}\``,
                                inline: true
                            },
                            {
                                name: "⏱️ **Data de Criação**:",
                                value: `<t:${moment(user_data.user.createdAt).unix()}:R>`,
                                inline: false
                            }
                            )
                    }

                    if (user_data.user.legacyUsername) {
                        embed.setTitle(`**Badges**: ${user_badges}<:lgc:1120563735212343366>`)
                        embed.setFields(
                            {
                                name: "👥 **Usuário**:",
                                value: `${user_data.user.globalName} \`@${user_data.user.username}\` (Originalmente ${user_data.user.legacyUsername})`,
                                inline: true,
                            }, 
                            {
                                name: "🆔 **ID**:",
                                value: `\`${user_data.user.id}\``,
                                inline: true
                            }, 
                            {
                                name: "⏱️ **Data de Criação**:",
                                value: `<t:${moment(user_data.user.createdAt).unix()}:R>`,
                                inline: false
                            }
                            )
                    } if (user_data.user.globalName) {
                        embed.setTitle(`**Badges**: ${user_badges}`)
                        embed.setFields(
                            {
                                name: "👥 **Usuário**:",
                                value: `${user_data.user.globalName} \`@${user_data.user.username}\``,
                                inline: true,
                            }, 
                            {
                                name: "🆔 **ID**:",
                                value: `\`${user_data.user.id}\``,
                                inline: true
                            },
                            {
                                name: "⏱️ **Data de Criação**:",
                                value: `<t:${moment(user_data.user.createdAt).unix()}:R>`,
                                inline: false
                            }
                            )
                    } else {
                        embed.setTitle(`**Badges**: ${user_badges}`)
                        embed.setFields(
                            {
                                name: "👥 **Usuário**:",
                                value: `\`@${user_data.user.username}\``,
                                inline: true,
                            }, 
                            {
                                name: "🆔 **ID**:",
                                value: `\`${user_data.user.id}\``,
                                inline: true
                            },
                            {
                                name: "⏱️ **Data de Criação**:",
                                value: `<t:${moment(user_data.user.createdAt).unix()}:R>`,
                                inline: false
                            }
                            )
                    }
                    if (user_data.boost) {
                        var boost_atual: string = (user_data.boost.boost)
                        var proximo_lvl: string = (user_data.boost.nextBoost)

                        var atual_emoji: string = badges__[boost_atual] || boost_atual;
                        var next_emoji: string = badges__[proximo_lvl] || proximo_lvl;

                        embed.addFields(
                            {
                                name: "⌚ **Boost Atual**",
                                value: `${atual_emoji} <t:${moment(user_data.boost.boostDate).unix()}:R>`,
                                inline: true,
                            }
                        )
                        if (boost_atual !== "BoostLevel9") {
                            embed.addFields(
                                {
                                    name: "🚀 **Próximo Up**",
                                    value: `${next_emoji} <t:${moment(user_data.boost.nextBoostDate).unix()}:R>`,
                                    inline: true,
                                }
                            )
                        }
                    }
                    await enviar_usuario(embed)
                }
            } else {
                console.log("[DS] Usuário sem badges!")
            }
        } catch (e) {
            console.log(e)
        }
    }
}
DScraper()