import { Client, ClientEvents } from "discord.js-selfbot-v13";
import fs from "fs";
import path from "path";
import "dotenv/config";
import { EventType } from "./types/Event";

const fileCondition = (fileName: string) => fileName.endsWith(".ts") || fileName.endsWith(".js");
export class SelfBotClient extends Client {
    constructor() {
        super({
            checkUpdate: false
        })
    }
    public start(){
        this.registerEvents();
        this.login(process.env.TOKEN)
    }
    private registerEvents() {
        const eventsPath = path.join(__dirname, "..", "events");
        fs.readdirSync(eventsPath).forEach(local => {
            fs.readdirSync(`${eventsPath}/${local}/`).filter(fileCondition)
            .forEach(async fileName => {
                const { name, once, run }: EventType<keyof ClientEvents> = (await import(`../events/${local}/${fileName}`))?.default
                try {
                    if (name) (once) ? this.once(name, run) : this.on(name, run);
                } catch(error) {
                    console.log(error);
                }
            })
        })
    }
}
