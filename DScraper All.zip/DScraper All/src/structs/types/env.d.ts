declare namespace NodeJS {
    interface ProcessEnv {
        TOKEN: string;
    }
}