import { SelfBotClient } from "./structs/SelfClient";


const self = new SelfBotClient();
self.start();

export default self
