import self from "../../index";
import { Event } from "../../structs/types/Event";
import fs from "fs";
import path from "path";
import readline from "readline";


export default new Event({
    name: "ready", 
    once: true,
    async run() {
        console.log("[DS]", `Connected in ${self.user?.displayName} | (@${self.user?.username}).`)
        const rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        rl.question("[DS] Paste the ID of the server you want to scrap: ", async (SERVER_ID) => {
            console.log("[DS]", "Starting the scrap");
            try {
                const server = await self.guilds.fetch(SERVER_ID)
                const members = await server.members.fetch();
        
                const membersIDS = members.map(member => member.user.id);
                const saveFolderPath = path.join(process.cwd(), 'saves');
                if(!fs.existsSync(saveFolderPath)) {
                    fs.mkdirSync(saveFolderPath);
           }
                const saveFilePath = path.join(saveFolderPath, `${server.memberCount}.txt`);
                fs.writeFileSync(saveFilePath, membersIDS.join('\n'));
                console.log("[DS]", `Saved the member ids from the server ${server.name} | ${server.memberCount} members`)
        
            } catch(error) {
                console.log(error)
            }
        }
        )
        
    }
})